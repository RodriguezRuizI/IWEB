import React from 'react';
import { View } from 'react-native';
import { createStore } from 'redux';
import { Provider } from 'react-redux';
import GlobalState from './../redux/reducers';
import { createAppContainer } from 'react-navigation';
import { createStackNavigator } from 'react-navigation-stack';
import HomeScreen from '../components/HomeScreen';
import GameScreen from '../components/GameScreen';

const AppNavigator = createStackNavigator({
    HomeScreen: { screen: HomeScreen },
    GameScreen: { screen: GameScreen }
    },{
    initialRouteName: "HomeScreen",
    headerMode: 'none'
})
const AppContainer = createAppContainer(AppNavigator);


export default class ReduxProvider extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            score: 0,
            finished: false,
            currentQuestion: 0,
            questions: []
        };        
        this.store = this.configureStore();
    }
    render() {
        return (
            <Provider store={ this.store }>
                <AppContainer />
            </Provider>
        );
    }
    configureStore() {
        return createStore(GlobalState, this.initialState);
    }
}
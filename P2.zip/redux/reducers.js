import { combineReducers } from 'redux';
import { QUESTION_ANSWER, CHANGE_QUESTION, SUBMIT, INIT_QUESTIONS } from './actions';


function score(state = 0, action = {}) {
	switch(action.type) {
		case SUBMIT:
			state = 0;
			if (action.payload.questions)
			action.payload.questions.map( (question) => {
				if ((question.userAnswer !== undefined) && (question.answer.toLowerCase() === question.userAnswer.toLowerCase())) {
					return state++;
				}
			});
			return state;
		default:
			return state;
	}
}


function finished(state = false, action = {}) {
	switch(action.type) {
		case SUBMIT:
			state = true;
			return state;
		default:
			return state;
	}
}

function currentQuestion(state = 0, action = {}) {
	switch(action.type) {
		case CHANGE_QUESTION:
			if (action.payload.int === 0) {
				//Tenemos que pasar a la siguiente pregunta
				if (action.payload.index === action.payload.questions.length-1) {
					// Si ya estamos en la ultima, deshabilitamos boton.
					return state = action.payload.questions.length-1;
				}
				return (state + 1);
			} else if (action.payload.int === 1) {
				//Tenemos que volver a la anterior pregunta
				if (action.payload.index === 0) {
					//Si ya estamos en la primera, deshabilitamos boton.
					return state = 0;
				}
				return (state - 1);
			}
		default:
			return state;
	}
}

function questions(state = [], action = {}) {
	switch(action.type) {
		case QUESTION_ANSWER:
			return state.map((question, i) => {
				return { ...question,
						userAnswer: action.payload.index === i ?
						action.payload.answer : question.userAnswer
				}
			});
		case INIT_QUESTIONS:
			state = action.payload.questions;
			return state;
		default:
			return state;
	}
}


const GlobalState = (combineReducers({
	score,
	finished,
	currentQuestion,
	questions
}));

export default GlobalState;
import React from 'react';
import { View } from 'react-native';

import ButtonComponent from './ButtonComponent';

export default class Actionbar extends React.Component {
	render() {
		return (
			<View>
				<View style={{flex:1, flexDirection: 'row', justifyContent: 'space-around', alignItems: 'center'}}>
					<ButtonComponent text="<" 
						disabled={false} 
						action={() => {this.props.navigation.goBack()}}
					/>
					<ButtonComponent text="Previous" 
						disabled={(this.props.currentQuestion === 0) || (this.props.questions.length === 0)} 
						action={this.props.changePrevGame}
					/>
					<ButtonComponent text="Submit" 
						disabled={this.props.questions.length === 0} 
						action={this.props.scoreGame}
					/>
					<ButtonComponent text="Next" 
						disabled={(this.props.currentQuestion === this.props.questions.length-1) || (this.props.questions.length === 0)}
						action={this.props.changeNextGame}
					/>
				</View>
				<View style={{flex:1, flexDirection: 'row', justifyContent: 'space-around', alignItems: 'center'}}>
					<ButtonComponent text="Save" 
						disabled={false} 
						action={this.props.save}
					/>
					<ButtonComponent text="Load" 
						disabled={false} 
						action={this.props.load}
					/>
					<ButtonComponent text="Remove" 
						disabled={false}
						action={this.props.remove}
					/>
				</View>
			</View>
			
		);
	}
}
import React from 'react';
import { View, Text } from 'react-native';


export default class Navbar extends React.Component {
	render() {
		return (
			<View style={{backgroundColor: '#007bff', flex: 1, alignItems: 'center', justifyContent: 'center'}}>
				<Text align='center' style={{fontSize: 20, fontWeight: 'bold', color: 'white'}}>QUIZ GAME</Text>
			</View>
		);
	}
}
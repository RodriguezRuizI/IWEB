import React from 'react';
import { Text, View } from 'react-native';

export default class Question extends React.Component {
	render() {
		return (
			<View>
				<Text style={{fontSize: 32, fontWeight: 'bold'}}>{this.props.question.question}</Text>
			</View>
		);
	}
}
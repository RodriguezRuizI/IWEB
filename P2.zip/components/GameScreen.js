import React from 'react';
import { AsyncStorage, Text, View } from 'react-native';
import { connect } from 'react-redux';
import Game from './Game';
import { questionAnswer,  changeQuestion, submit, initQuestions } from '../redux/actions';
import Navbar from './Navbar';



class App extends React.Component {

	async _saveData(questions){
		try {
			var currentQuestions = JSON.stringify(questions);
			await AsyncStorage.setItem('@P2_2019_IWEB:quiz', currentQuestions);	
			alert("Saved data");
		} catch (error) { 
			alert("ERROR: No saved data. " + error); 
		}
	}

	async _loadData(){
		try {
			let value = await AsyncStorage.getItem('@P2_2019_IWEB:quiz');
			if (value !== null) {alert("Data has been loaded");}
			else {alert("ERROR: No data found. " + error); }
		} catch (error) { 
			alert("ERROR: No data found. " + error); 
		}
	}

	async _removeData(){
		try {
			await AsyncStorage.removeItem('@P2_2019_IWEB:quiz');
			alert("Data has been removed");
		} catch (error) { 
			alert("ERROR: Data found. " + error); 
		}
	}

	componentDidMount() {
        fetch('https://quiz.dit.upm.es/api/quizzes/random10wa?token=11a5eb64bda6eabf43f5')
	    .then((questions) => questions.json())
	    .then((serverQuestions) => {this.props.dispatch(initQuestions(serverQuestions));})
	    .catch((error) => {console.error(error);});
	}

    render() {
    	if (this.props.questions.length === 0) {
    		return <Text h1>Cargando... Aún no se han recibido las preguntas</Text>;
    	} else {
	    	return (
                <View style={{flex: 1, flexDirection: 'column', justifyContent: 'space-around', alignItems: 'center', backgroundColor: '#007bff'}}>
					<View style={{flex:1, marginTop: 10, alignSelf: 'stretch'}}>
						<Navbar />
					</View>
					<View style={{flex:8, margin: 20, backgroundColor: 'white', borderRadius: 20}}>
						<Game style={{padding: 10}} question={this.props.questions[this.props.currentQuestion]} 
							questions={this.props.questions}
							currentQuestion={this.props.currentQuestion}
							changePrevApp={() => {
								this.props.dispatch(changeQuestion(1, this.props.currentQuestion, this.props.questions));
							}} 
							changeNextApp={() => {
								this.props.dispatch(changeQuestion(0, this.props.currentQuestion, this.props.questions));
							}} 
							scoreApp={() => {
								this.props.dispatch(submit(this.props.questions));
								alert("Your score is: " + this.props.score);
							}}
							onQuestionAnswer={(answer) => {
								this.props.dispatch(questionAnswer(this.props.currentQuestion, answer))
							}}
							navigation={this.props.navigation}
							load={() => {this._loadData()}}
							save={() => {this._saveData(this.props.questions)}}
							remove={() => {this._removeData()}}
						/>
					</View>
				</View>
	    	);
    	}
    }
}

function mapStateToProps(state) {
  return { 
    ...state 
  };
}

export default connect(mapStateToProps)(App);

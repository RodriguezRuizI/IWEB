import React from 'react';
import { View, Text, Image, FlatList } from 'react-native';

import Question from './Question';
import Answer from './Answer';

export default class Content extends React.Component {
	render() {
		if (this.props.question) {
			let questionPhotoUrl = this.props.question.attachment.url;
			let authorPhotoUrl = this.props.question.author.photo.url;
			let tips = this.props.question.tips;
			return (
				<View style={{flex:1, flexDirection: 'column', justifyContent: 'space-around', alignItems: 'center'}}>
					<View style={{flex: 10}}><Image style={{width: 290, height: 220, borderRadius: 20}} source={{uri: questionPhotoUrl}} accessibiltyLabel="Imagen país" /></View>
					<View style={{flex: 3, flexDirection: 'row', justifyContent: 'space-around', alignItems: 'center'}}>
						<Image style={{width: 50, height: 50, borderRadius: 20}} source={{uri: authorPhotoUrl}} accessibiltyLabel="Foto de perfil" />
						<Text style={{marginLeft: 5}}>Created by {this.props.question.author.username}</Text>
					</View>
					<View style={{flex: 2}}><Question question={this.props.question} style={{textAlign: 'center', fontWeight: 'bold'}}/></View>
					<View style={{flex: 1}}><Text>(Question {this.props.currentQuestion+1}/{this.props.questions.length})</Text></View>
					<View style={{flex: 2, width: 320}}><Answer question={this.props.question} onQuestionAnswer={this.props.onQuestionAnswer}/></View>
					<View style={{flex: 3, flexDirection: 'column', justifyContent: 'space-around', alignItems: 'center'}}>
						<Text style={{fontSize: 15, fontWeight: 'bold'}}>Tips</Text>
						{this.props.question.tips.lenght !== 0 ? 
							(<FlatList 
								data={tips}
								renderItem={({item}) => {return (<Text>{item}</Text>)}}
								keyExtractor={(item: object) => Math.random()}
							/>) :
							(<Text>No tips.</Text>)
						}
					</View>
				</View>
			);
		} else {
			return (<Text>No hay question</Text>);
		}
	}
}
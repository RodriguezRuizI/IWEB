import React from 'react';
import { Button } from 'react-native';


export default class ButtonComponent extends React.Component {
	render() {
		return (
			<Button onPress={this.props.action} 
				disabled={this.props.disabled} 
				title={this.props.text} 
			/>
		);
	}
}
import React from 'react';
import { View } from 'react-native';

import Content from './Content';
import Actionbar from './Actionbar';

export default class Game extends React.Component {
	render() {
		return (
			<View style={{flex: 1, flexDirection: 'column', justifyContent: 'flex-start', alignItems: 'center'}}>
				<View style={{flex:5}}>
					<Content question={this.props.question} 
						onQuestionAnswer={this.props.onQuestionAnswer} 
						questions={this.props.questions}
						currentQuestion={this.props.currentQuestion}
					/>
				</View>
				<View style={{flex:1}}>
					<Actionbar currentQuestion={this.props.currentQuestion}
						questions={this.props.questions} 
						scoreGame={this.props.scoreApp}
						changePrevGame={this.props.changePrevApp}
						changeNextGame={this.props.changeNextApp}
						navigation={this.props.navigation} 
						load={this.props.load}
						save={this.props.save}
						remove={this.props.remove}
					/>
				</View>
			</View>
		);
	}
}
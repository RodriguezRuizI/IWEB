import React from 'react';
import { View, TextInput } from 'react-native';


export default class Answer extends React.Component {
	render() {
		return (
			<View>
				<TextInput 
					style={{borderRadius: 4, borderWidth: 2, borderColor: 'green', padding: 10}}
					placeholder="Enter your answer here"
					value={this.props.question.userAnswer || ''}
					onChangeText={(text)=>this.props.onQuestionAnswer(text)}
				/>
			</View>
		);
	}
}
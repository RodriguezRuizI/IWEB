import React from 'react';
import { View, Text, Image } from 'react-native';
import ButtonComponent from './ButtonComponent';

export default class HomeScreen extends React.Component {
    render() {
        return (
            <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
                <Text style={{fontSize: 32, fontWeight: 'bold'}}>Welcome to the game</Text>
                <Image source={require('../assets/giphy.gif')} style={{width: '90%'}} />
                <ButtonComponent action={() => {this.props.navigation.navigate('GameScreen')}} disabled={false} text={"Start!"} />
            </View>
        );
    }
}
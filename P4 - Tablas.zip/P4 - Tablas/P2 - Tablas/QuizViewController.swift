//
//  QuizViewController.swift
//  P2 - Tablas
//
//  Created by Belén on 14/11/2019.
//  Copyright © 2019 IWEB. All rights reserved.
//

import UIKit

class QuizViewController: UIViewController {

    var quiz: QuizItem!
    
    @IBOutlet weak var questionLabel: UILabel!
    @IBOutlet weak var attachmentImageView: UIImageView!
    @IBOutlet weak var photoImageView: UIImageView!
    @IBOutlet weak var authorLabel: UILabel!
    @IBOutlet weak var answerTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        questionLabel.text = quiz.question
        questionLabel.layer.cornerRadius = 5
        
        attachmentImageView.image = UIImage(named: "none")
        photoImageView.image = UIImage(named: "none")
        
        if let url1 = quiz.attachment?.url {
            attachmentImageView.image = image(url: url1)
        }
        
        if let url2 = quiz.author?.photo?.url {
            photoImageView.image = image(url: url2)
        }
        
        authorLabel.text = quiz.author?.username
        
        answerTextField.layer.borderWidth = 2
        answerTextField.layer.borderColor = UIColor(red: 148.0, green: 17.0, blue: 0.0, alpha: 1.0).cgColor
        
    }
    
    
    @IBAction func finished(_ sender: UITextField) {
        checkAnswer()
    }
    
    

    @IBAction func checkAnswer() {
        let resp = answerTextField.text?.lowercased()
        let respOK = quiz.answer.lowercased()
        if resp == respOK {
            alert(msg: "Congrats! Your answer is right.")
        } else {
            alert(msg: "Oops... Try again!")
        }
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

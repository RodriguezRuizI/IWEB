//
//  QuizModel.swift
//  P2 - Tablas
//
//  Created by Patricia on 14/11/2019.
//  Copyright © 2019 IWEB. All rights reserved.
//

import Foundation

struct QuizItem: Codable {
    let id: Int
    let question: String
    let answer: String
    let author: Author?
    let attachment: Attachment?
    let favourite: Bool
    let tips: [String]
    
    struct Author: Codable {
        let isAdmin: Bool?
        let username: String
        let photo: Attachment?
    }

    struct Attachment: Codable {
        let filename: String
        let mime: String
        let url: URL?
    }
}


//https://quiz.dit.upm.es/api/quizzes/random10wa?token=11a5eb64bda6eabf43f5


/*var datos = {
   "id":42,
   "question":"What flexbox property indicates how to align items in the secondary axis?",
   "answer":"align-items",
   "author":{
      "id":104,
      "isAdmin":false,
      "username":"sonsoles",
      "photo":{
         "filename":"Captura de pantalla 2019-09-20 a las 11.46.06.png",
         "mime":"image/png",
         "url":"https://quiz.dit.upm.es/uploads/e4df469d881176e6ea034209fa5a535583233ce5e0b85f698d60451ffe0370bf"
      }
   },
   "attachment":{
      "filename":"align1.png",
      "mime":"image/png",
      "url":"https://quiz.dit.upm.es/uploads/b29b8664482a14a03acd75a133503c98853a06b69c4e79a213ca03db5b00a72a"
   },
   "favourite":false,
   "tips":[

   ]
}*/




class QuizModel {
    
    var quizzes = [QuizItem]()
    
    func download() {
        
        let surl = "https://quiz.dit.upm.es/api/quizzes/random10wa?token=11a5eb64bda6eabf43f5"
        
        guard let url = URL(string: surl) else {
            print("No ha sido posible pasar la url de string")
            return
        }
        do {
            let data = try Data(contentsOf: url)
            /*//Para depurar
            let letra = String(data: data, encoding: .utf8)
            print(letra)*/
            
            let decoder = JSONDecoder()
            
            let quizzes = try decoder.decode([QuizItem].self, from: data)
            
            self.quizzes = quizzes
            
            
        } catch let error {
            print(error)
        }
        

        
    }
}

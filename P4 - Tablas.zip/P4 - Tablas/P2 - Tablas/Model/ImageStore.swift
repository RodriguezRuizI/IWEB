//
//  ImageStore.swift
//  P2 - Tablas
//
//  Created by Patricia on 14/11/2019.
//  Copyright © 2019 IWEB. All rights reserved.
//

import UIKit


var imageCache = [URL: UIImage]()

func image(url: URL) -> UIImage {
    
    //me la bajo si esta en la cache
    if let img = imageCache[url] {
        return img
    }
     //me la bajo nueva y la guardo en la cache
    if let data = try? Data(contentsOf: url), let img = UIImage(data: data) {
        imageCache[url] = img
        return img
    }
    
    return UIImage(named: "error")!
}

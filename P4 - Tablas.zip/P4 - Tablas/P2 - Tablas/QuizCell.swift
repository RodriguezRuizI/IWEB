//
//  QuizCell.swift
//  P2 - Tablas
//
//  Created by Belén on 21/11/2019.
//  Copyright © 2019 IWEB. All rights reserved.
//

import UIKit

class QuizCell: UITableViewCell {

    @IBOutlet weak var questionLabel: UILabel!
    @IBOutlet weak var imageImageView: UIImageView!

}

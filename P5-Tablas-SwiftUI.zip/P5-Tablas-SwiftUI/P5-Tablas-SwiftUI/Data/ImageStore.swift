//
//  ImageStore.swift
//  P5-Tablas-SwiftUI
//
//  Created by Patricia on 28/11/2019.
//  Copyright © 2019 IWEB. All rights reserved.
//

import SwiftUI

class ImageStore: ObservableObject {
    
    @Published var imageCache = [URL: UIImage]()
    
    let defaultImage = UIImage(named: "none")!

    func image(url: URL?) -> UIImage {
        guard let url = url else {
            return defaultImage
        }
        //me la bajo si esta en la cache
        if let img = imageCache[url] {
            return img
        }
        self.imageCache[url] = defaultImage
        
        //me la bajo nueva y la guardo en la cache
        DispatchQueue.global().async {
            if let data = try? Data(contentsOf: url),
            let img = UIImage(data: data) {
                DispatchQueue.main.async {
                    self.imageCache[url] = img
                }
            }
        }
        return defaultImage
    }
}



//
//  QuizModel.swift
//  P5-Tablas-SwiftUI
//
//  Created by Patricia on 28/11/2019.
//  Copyright © 2019 IWEB. All rights reserved.
//

import UIKit

struct QuizItem: Codable, Identifiable {
    let id: Int
    let question: String
    let answer: String
    let author: Author?
    let attachment: Attachment?
    var favourite: Bool
    let tips: [String]
    
    struct Author: Codable {
        let isAdmin: Bool?
        let username: String
        let photo: Attachment?
    }
    
    struct Attachment: Codable {
        let filename: String
        let mime: String
        let url: URL?
    }
}

class QuizModel: ObservableObject{
    
    @Published var quizzes = [QuizItem]()

    let session = URLSession.shared
    
    func download() {
        let surl = "https://quiz.dit.upm.es/api/quizzes/random10wa?token=11a5eb64bda6eabf43f5"
        guard let url = URL(string: surl) else {
            print("Hay error")
            return
        }
        
        DispatchQueue.global().async {
            do {
                let data = try Data(contentsOf: url)
                let decoder = JSONDecoder()
                
                let quizzes = try decoder.decode([QuizItem].self, from: data)
                
                DispatchQueue.main.async {
                    self.quizzes = quizzes
                    print("Terminando la descarga")
                }
            } catch {
                DispatchQueue.main.async {
                    print("Algo chungo ha pasado")
                }
            }
        }
    }
    
    func toggleFavourite (_ quizItem: QuizItem) {
        
        guard let index = quizzes.firstIndex(where: {$0.id == quizItem.id})
            else {
                print("No existe el quiz con id: \(quizItem.id)")
                return
        }
        print("hay index")
        let surl = "https://quiz.dit.upm.es/api/users/tokenOwner/favourites/\(quizItem.id)?token=11a5eb64bda6eabf43f5"
        guard let url = URL(string: surl) else {
            print("Hay error")
            return
        }
        print("hay url")
        var request = URLRequest(url: url)
        request.httpMethod = quizItem.favourite ? "DELETE" : "PUT"
        request.addValue("XMLHttpRequest", forHTTPHeaderField: "X-Requested-With")
        print("hay request")
        //tarea
        let task = session.uploadTask(with: request, from: Data()) {
            (data: Data?, res: URLResponse?, error: Error?) in
            print("Haciendo request")
            if error != nil {
                print(error!.localizedDescription)
                return
            }
            // Si el codigo es 200 significa que el cambio se ha realizado con exito
            let code = (res as! HTTPURLResponse).statusCode
            if code != 200 {
                print("error:")
                print(HTTPURLResponse.localizedString(forStatusCode: code))
                return
            }
            
            print("Favorito actualizado")
            
            DispatchQueue.main.async {
                self.quizzes[index].favourite.toggle()
            }
        }
        task.resume()
    }
    
}


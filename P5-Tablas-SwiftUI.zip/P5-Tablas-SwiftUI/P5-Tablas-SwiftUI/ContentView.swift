//
//  ContentView.swift
//  P5-Tablas-SwiftUI
//
//  Created by Patricia on 28/11/2019.
//  Copyright © 2019 IWEB. All rights reserved.
//

import SwiftUI

var defaults: UserDefaults = UserDefaults.standard

struct ContentView: View {
    
    @EnvironmentObject var quizModel : QuizModel
    
    @State var okIDs: [Int] = []

    var body: some View {
        
        let bindingOkIDs = Binding(
            get: { self.okIDs },
            set: { defaults.set($0, forKey: "okIDs")
                self.okIDs = $0 })
        
        return NavigationView {
            List {
                ForEach(quizModel.quizzes) { quizItem in
                    NavigationLink(destination: QuizDetail(quizItem: quizItem, bindingOkIDs: bindingOkIDs)) {
                        QuizRow(quizItem: quizItem)
                    }
                }
            }
            .navigationBarTitle("P5 QUIZ")
            .navigationBarItems(
                leading: Text("Points: \(okIDs.count)"),
                trailing: Button(action: {
                    self.quizModel.download()
                }, label: {
                    Image("replay")
                        .resizable()
                        .frame(width: 30, height: 30)
                }))
        }
    .onAppear(perform: {
        self.okIDs = defaults.object(forKey: "okIDs") as? [Int] ?? []
    })
        
    }
}

struct ContentView_Previews: PreviewProvider {
    
    static let quizModel: QuizModel = {
        let qm = QuizModel()
        qm.download()
        return qm
    }()
    
    static let imageStore = ImageStore()
    
    static var previews: some View {
        ContentView()
            .environmentObject(quizModel)
            .environmentObject(imageStore)
    }
}

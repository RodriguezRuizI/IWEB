//
//  QuizDetail.swift
//  P5-Tablas-SwiftUI
//
//  Created by Patricia on 28/11/2019.
//  Copyright © 2019 IWEB. All rights reserved.
//

import SwiftUI

struct QuizDetail: View {
    
    @EnvironmentObject var quizModel: QuizModel
    @EnvironmentObject var imageStore: ImageStore
    
    var quizItem: QuizItem
    
    var bindingOkIDs: Binding<[Int]>
    
    @State var answer: String = ""
    
    @State private var showAlert: Bool = false
    
    var body: some View {
        VStack {
            ZStack {
                Image(uiImage: self.imageStore.image(url: self.quizItem.attachment?.url))
                    .resizable()
                    .frame(width: 300, height: 300)
                Circle()
                    .foregroundColor(Color.white)
                    .frame(width: 40, height: 40)
                    .offset(x: 130, y: 130)
                Button(action: {
                    self.quizModel.toggleFavourite(self.quizItem)
                }) {
                    self.quizItem.favourite ?
                        Image("star_on")
                            .resizable()
                            .frame(width: 30, height: 30) 
                        : Image("star_off")
                            .resizable()
                            .frame(width: 30, height: 30)
                }
                .buttonStyle(PlainButtonStyle())
                .offset(x: 130, y: 130)
            }
            HStack {
                Image(uiImage: self.imageStore.image(url: self.quizItem.author?.photo?.url))
                    .resizable()
                    .frame(width: 40, height: 40)
                    .clipShape(Circle())
                Text(self.quizItem.author?.username ?? "Anónimo")
            }
            Text(self.quizItem.question)
                .font(.title)
                .fontWeight(.bold)
            TextField("Type your answer here...", text: self.$answer,
                      onCommit: {
                        self.showAlert = true
                        if self.answer.caseInsensitiveCompare(self.quizItem.answer) == ComparisonResult.orderedSame {
                            if !self.bindingOkIDs.wrappedValue.contains(self.quizItem.id) {

                                var localOkIDs: [Int] = self.bindingOkIDs.wrappedValue
                                localOkIDs.append(self.quizItem.id)
                                self.bindingOkIDs.wrappedValue = localOkIDs
                            }
                        }
            })
                .padding(.all, 50)
                .alert(isPresented: self.$showAlert) {
                    Alert(title: Text("Your answer is..."), message: Text(                        self.answer.caseInsensitiveCompare(self.quizItem.answer) == ComparisonResult.orderedSame ?
                        "Right! Congratulations!" :
                        "Wrong :( We're sorry..."
                    ), dismissButton: .default(Text("Keep playing")))
            }
            Text("Points: \(self.bindingOkIDs.wrappedValue.count)")
            Button(action: {
                
                self.bindingOkIDs.wrappedValue = []
            }) {
                Text("Reset points")
            }
            .padding()
        }
    }
}

struct QuizDetail_Previews: PreviewProvider {
    
    static let quizModel: QuizModel = {
        let qm = QuizModel()
        qm.download()
        return qm
    }()
    
    static let imageStore = ImageStore()
    
    static var previews: some View {
        QuizDetail(quizItem: self.quizModel.quizzes[0], bindingOkIDs: .constant([1, 2, 3]))
            .environmentObject(quizModel)
            .environmentObject(imageStore)
    }
}


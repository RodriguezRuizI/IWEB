//
//  QuizRow.swift
//  P5-Tablas-SwiftUI
//
//  Created by Patricia on 28/11/2019.
//  Copyright © 2019 IWEB. All rights reserved.
//

import SwiftUI


struct QuizRow: View {
    
    @EnvironmentObject var quizModel: QuizModel
    @EnvironmentObject var imageStore: ImageStore
    
    var quizItem: QuizItem
    
    var body: some View {
        HStack {
            Image(uiImage: self.imageStore.image(url: self.quizItem.attachment?.url))
                .resizable()
                .frame(width: 120, height: 120)
                .clipShape(Circle())
            VStack {
                HStack {
                    Button(action: {
                        self.quizModel.toggleFavourite(self.quizItem)
                    }) {
                        self.quizItem.favourite ? Image("star_on") : Image("star_off")
                    }
                    .buttonStyle(PlainButtonStyle())
                    Spacer()
                    VStack {
                        Image(uiImage: self.imageStore.image(url: self.quizItem.author?.photo?.url))
                            .resizable()
                            .frame(width: 40, height: 40)
                            .clipShape(Circle())
                        Text(self.quizItem.author?.username ?? "Anónimo")
                    }
                }
                Text(self.quizItem.question)
                    .font(.title)
                    .fontWeight(.bold)
                Text("")
            }
        }
    }
}

struct QuizRow_Previews: PreviewProvider {
    
    static let quizModel: QuizModel = {
        let qm = QuizModel()
        qm.download()
        return qm
    }()
    
    static let imageStore = ImageStore()
    
    static var previews: some View {
        QuizRow(quizItem: self.quizModel.quizzes[0])
        .environmentObject(quizModel)
        .environmentObject(imageStore)
    }
}

# Project Files: Building Lists and Navigation

To follow the [Building Lists and Navigation](https://developer.apple.com/tutorials/swiftui/building-lists-and-navigation)  tutorial, open the Xcode project in the **StartingPoint** folder. To explore on your own, open the Xcode project in the **Complete** folder and browse the project's code.

- Note: To preview and interact with views from the canvas in Xcode ensure your Mac is running macOS 10.15 beta. 

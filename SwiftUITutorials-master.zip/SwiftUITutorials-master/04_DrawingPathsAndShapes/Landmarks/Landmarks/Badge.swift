//
//  Badge.swift
//  Landmarks
//
//  Created by Sean O'Neal on 12/6/19.
//  Copyright © 2019 Apple. All rights reserved.
//

import SwiftUI

struct Badge: View {
    var body: some View {
        BadgeBackground()
    }
}

struct Badge_Previews: PreviewProvider {
    static var previews: some View {
        Badge()
    }
}

//
//  ViewController.swift
//  P3-Hola-Mundo
//
//  Created by Isabel  on 23/10/2019.
//  Copyright © 2019 Isabel Rodríguez Ruiz. All rights reserved.
//

import UIKit
import MapKit

class ViewController: UIViewController {

    @IBOutlet weak var msgLabel: UILabel!
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var place: MKMapView!
    @IBOutlet weak var controlMap: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func cibelesUpdate(_ sender: UIButton) {
        msgLabel.text = "Cibeles"
        let center = CLLocationCoordinate2D(latitude: 40.419556, longitude: -3.69307)
        let span = MKCoordinateSpan(latitudeDelta: 0.003, longitudeDelta: 0.003)
        let reg = MKCoordinateRegion(center: center, span: span)
        place.setRegion(reg, animated: true)
    }
    
    @IBAction func telecoUpdate(_ sender: UIButton) {
        msgLabel.text = "Teleco"
        let center = CLLocationCoordinate2D(latitude: 40.452445, longitude: -3.726162)
        let span = MKCoordinateSpan(latitudeDelta: 0.003, longitudeDelta: 0.003)
        let reg = MKCoordinateRegion(center: center, span: span)
        place.setRegion(reg, animated: true)
    }
    
    @IBAction func wandaUpdate(_ sender: UIButton) {
        msgLabel.text = "Wanda Metropolitano"
        msgLabel.font = UIFont.systemFont(ofSize: 30)
        let center = CLLocationCoordinate2D(latitude: 40.43621, longitude: -3.5994827)
        let span = MKCoordinateSpan(latitudeDelta: 0.003, longitudeDelta: 0.003)
        let reg = MKCoordinateRegion(center: center, span: span)
        place.setRegion(reg, animated: true)
    }
    
    @IBAction func changeTitle(_ sender: UISlider) {
        msgLabel.alpha = CGFloat(sender.value)
    }
    
    @IBAction func mapUpdate(_ sender: UISegmentedControl) {
        
        switch
            controlMap.selectedSegmentIndex
        {
        case 0:
                place.mapType = MKMapType.standard
        case 1:
            place.mapType = MKMapType.satellite
        case 2:
            place.mapType = MKMapType.hybrid
        default:
            break
        }
    }
    
}

import React from 'react';
import ReactDOM from 'react-dom';
import ReduxProvider from './redux/reduxProvider';
import * as serviceWorker from './serviceWorker';
import 'bootstrap/dist/css/bootstrap.min.css';


ReactDOM.render(<ReduxProvider />, document.getElementById('root'));

serviceWorker.unregister();

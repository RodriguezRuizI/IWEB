import { combineReducers } from 'redux';
import { QUESTION_ANSWER, CHANGE_QUESTION, SUBMIT, INIT_QUESTIONS, TIMER, CHANGE_QUESTION_TO } from './actions';


function score(state = 0, action = {}) {
	switch(action.type) {
		case SUBMIT:
			state = 0;
			if (action.payload.questions)
			action.payload.questions.map( (question) => {
				if ((question.userAnswer !== undefined) && (question.answer.toLowerCase() === question.userAnswer.toLowerCase())) {
					return state++;
				}
				else {return state;}
			});
			return state;
		case TIMER:
				state = 0;
				if (action.payload.questions)
				action.payload.questions.map( (question) => {
					if ((question.userAnswer !== undefined) && (question.answer.toLowerCase() === question.userAnswer.toLowerCase())) {
						return state++;
					}
					else {return state;}
				});
				return state;
		case INIT_QUESTIONS:
			return state = 0;
		default:
			return state;
	}
}


function finished(state = false, action = {}) {
	switch(action.type) {
		case SUBMIT:
			state = true;
			return state;
		case INIT_QUESTIONS:
			return state = false;
		default:
			return state;
	}
}

function currentQuestion(state = 0, action = {}) {
	switch(action.type) {
		case CHANGE_QUESTION:
			if (action.payload.int === 0) {
				//Tenemos que pasar a la siguiente pregunta
				if (action.payload.index === action.payload.questions.length-1) {
					// Si ya estamos en la ultima, deshabilitamos boton.
					return state = action.payload.questions.length-1;
				}
				return (state + 1);
			} else if (action.payload.int === 1) {
				//Tenemos que volver a la anterior pregunta
				if (action.payload.index === 0) {
					//Si ya estamos en la primera, deshabilitamos boton.
					return state = 0;
				}
				return (state - 1);
			}
			return state;
		case INIT_QUESTIONS:
				return state = 0;
		case CHANGE_QUESTION_TO:
			state = action.payload.int;
			return state;
		default:
			return state;
	}
}

function questions(state = [], action = {}) {
	switch(action.type) {
		case QUESTION_ANSWER:
			return state.map((question, i) => {
				return { ...question,
						userAnswer: action.payload.index === i ?
						action.payload.answer : question.userAnswer
				}
			});
		case INIT_QUESTIONS:
			state = action.payload.questions;
			return state;
		default:
			return state;
	}
}

function timeFinished(state = false, action = {}) {
	switch(action.type) {
		case INIT_QUESTIONS:
			return state = false;
		case TIMER:
			return state = true;
		default:
			return state;
	}
}

const GlobalState = (combineReducers({
	score,
	finished,
	currentQuestion,
	questions,
	timeFinished
}));

export default GlobalState;
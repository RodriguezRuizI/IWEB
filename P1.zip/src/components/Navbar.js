import React from 'react';
//import { Nav, Navbar } from 'react-bootstrap';
import { Link } from 'react-router-dom';

export default class NavbarComponent extends React.Component {
	render() {
		return (
			<div style={{backgroundColor: '#007BFF', padding: 10}}> 
				<span style={{color: 'white', marginLeft: 10, fontSize: 25}}>QUIZ GAME |</span>
				<Link to="/"  style={{color: 'white', marginLeft: 10}}>Home</Link>
				<Link to="/game" style={{color: 'white', marginLeft: 10}}>Game</Link>
				<Link to="/authors" style={{color: 'white', marginLeft: 10}}>Authors</Link>
			</div>
		);
	}
}


/*<Navbar bg="primary" variant="dark" expand="lg">
					<Navbar.Brand href="home">Quiz Game</Navbar.Brand>
					<Navbar.Toggle aria-controls="basic-navbar-nav" />
					<Navbar.Collapse id="basic-navbar-nav">
						<Nav className="mr-auto">
							<Nav.Link href="home">Home</Nav.Link>
								<NavDropdown title="Game" id="basic-nav-dropdown">
									<NavDropdown.Item href="game">Play here!</NavDropdown.Item>
									<NavDropdown.Divider />
									<NavDropdown.Item href="/game/0">Question 1</NavDropdown.Item>
									<NavDropdown.Item href="/game/1">Question 2</NavDropdown.Item>
									<NavDropdown.Item href="/game/2">Question 3</NavDropdown.Item>
									<NavDropdown.Item href="/game/3">Question 4</NavDropdown.Item>
									<NavDropdown.Item href="/game/4">Question 5</NavDropdown.Item>
									<NavDropdown.Item href="/game/5">Question 6</NavDropdown.Item>
									<NavDropdown.Item href="/game/6">Question 7</NavDropdown.Item>
									<NavDropdown.Item href="/game/7">Question 8</NavDropdown.Item>
									<NavDropdown.Item href="/game/8">Question 9</NavDropdown.Item>
									<NavDropdown.Item href="/game/9">Question 10</NavDropdown.Item>
								</NavDropdown>
							<Nav.Link href="/authors">Authors</Nav.Link>
						</Nav>
					</Navbar.Collapse>
				</Navbar>*/
import React from 'react';
import { Button } from 'react-bootstrap';

export default class ButtonComponent extends React.Component {
	render() {
		return (
			<div>
				<Button type="button" onClick={this.props.action} disabled={this.props.disabled}>{this.props.text}</Button>
			</div>
		);
	}
}
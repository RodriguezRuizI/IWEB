import React from 'react';
import ButtonComponent from './Button';
import { Col, Row } from 'react-bootstrap';


export default class Actionbar extends React.Component {
	render() {
		return (
			<Row style={{width: '100%'}}>
				<Col md={{offset: 2}}>
					<ButtonComponent text="Previous" action={this.props.changePrev} disabled={(this.props.currentQuestion === 0) || (this.props.questions.length === 0)}/>
				</Col>
				<Col>
					<ButtonComponent text="Submit" action={this.props.score} disabled={this.props.questions.length === 0}/>
				</Col>
				<Col>
					<ButtonComponent text="Next" action={this.props.changeNext} disabled={(this.props.currentQuestion === this.props.questions.length-1) || (this.props.questions.length === 0)}/>
				</Col>
				<Col>
					<ButtonComponent text="Reset" action={this.props.reseteo} disabled={false} />
				</Col>
			</Row>
		);
	}
}
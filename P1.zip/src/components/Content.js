import React from 'react';
import Question from './Question';
import Answer from './Answer';
import { Col, Row, Button, ButtonGroup } from 'react-bootstrap';

export default class Content extends React.Component {
	
	render() {
		return (
			<div style={{marginLeft: '4%', marginTop: '2%'}}>
				<ButtonGroup style={{margin: 5, display: 'block', width: 600}} className="mr-2 text-center" aria-label="First group">
					<Button style={{margin: 'auto', display: 'inline'}} onClick={this.props.changeTo0}>1</Button>
					<Button style={{margin: 'auto', display: 'inline'}} onClick={this.props.changeTo1}>2</Button>
					<Button style={{margin: 'auto', display: 'inline'}} onClick={this.props.changeTo2}>3</Button>
					<Button style={{margin: 'auto', display: 'inline'}} onClick={this.props.changeTo3}>4</Button>
					<Button style={{margin: 'auto', display: 'inline'}} onClick={this.props.changeTo4}>5</Button>
					<Button style={{margin: 'auto', display: 'inline'}} onClick={this.props.changeTo5}>6</Button>
					<Button style={{margin: 'auto', display: 'inline'}} onClick={this.props.changeTo6}>7</Button>
					<Button style={{margin: 'auto', display: 'inline'}} onClick={this.props.changeTo7}>8</Button>
					<Button style={{margin: 'auto', display: 'inline'}} onClick={this.props.changeTo8}>9</Button>
					<Button style={{margin: 'auto', display: 'inline'}} onClick={this.props.changeTo9}>10</Button>
				</ButtonGroup>
				<Col style={{float: 'left'}}>
					<Row>
						{this.props.question.attachment === null ? {} : 
						<img src={this.props.question.attachment.url} style={{width: 600, height: 300, borderRadius: '100px'}} alt="Imagen país" />}
					</Row>
					<Row>
						<img src={this.props.question.author.photo.url} style={{width: 80, height: 60, borderRadius: '100px', margin: '5%'}} alt="Foto de perfil"/>
						<p style={{display: 'inline', marginTop: '8%'}}>Created by {this.props.question.author.username}</p>
					</Row>
				</Col>
				<Col md={{offset: 11}}>
					<Row>
						<Question style={{margin: '5%'}} question={this.props.question} />
					</Row>
					<Row>
						<Answer style={{margin: '15%'}} question={this.props.question} onQuestionAnswer={this.props.onQuestionAnswer}/>
					</Row>
						<div>
							{this.props.question.tips.length !== 0 ? 
								(<div><h2 style={{margin: '10%'}}>Tips</h2>
								<ul style={{marginLeft: '10%'}}>
									{this.props.question.tips.map((tipp) => {
										return <li>{tipp}</li>;
									})}
								</ul></div>) : (<p style={{margin: '10%'}}>No tips.</p>)
							}
						</div>				
				</Col>
			</div>
		);
	}
}
import React from 'react';


export default class Question extends React.Component {
	render() {
		return (
			<h1 style={{marginLeft: 40}}>{this.props.question.question}</h1>
		);
	}
}
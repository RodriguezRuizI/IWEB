import React from 'react';
import { Container, Row, Col, Card, Button } from 'react-bootstrap';

export default class Authors extends React.Component {
	render() {
		return (
			<div>
				<h1 align='center' style={{margin: 50}}>Authors</h1>
				<Container>
					<Row>
						<Col md={{offset: 2}}>
							<Card style={{ width: '18rem' }}>
								<Card.Img variant="top" src="pati.jpg"   height={390} style={{borderRadius: '100px'}} />
								<Card.Body>
									<Card.Title>Patricia Centenera Béjar</Card.Title>
									<Card.Text>
									Telecommunications Engineer student at UPM.
									</Card.Text>
									<a target="_blank" rel="noopener noreferrer" href="https://www.linkedin.com/in/pcentenerab/"><Button variant="primary">LinkedIn Profile</Button></a>
								</Card.Body>
							</Card>
						</Col>
						<Col>
							<Card style={{ width: '18rem' }}>
								<Card.Img variant="top" src="isa.png"   height={390} style={{borderRadius: '100px'}} />
								<Card.Body>
									<Card.Title>Isabel Rodríguez Ruiz</Card.Title>
									<Card.Text>
									Telecommunications Engineer student at UPM.
									</Card.Text>
									<a target="_blank" rel="noopener noreferrer" href="https://www.linkedin.com/in/isabel-rodríguez-ruiz096"><Button variant="primary">LinkedIn Profile</Button></a>
								</Card.Body>
							</Card>
						</Col>
					</Row>
				</Container>
			</div>
		);
	}
}
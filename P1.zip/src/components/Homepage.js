import React from 'react';
import { Link } from 'react-router-dom';

export default class Homepage extends React.Component {
	render() {
		return (
			<div>
				<h1 align='center' style={{margin: 50}}>Welcome to the game!</h1>
				<Link to='/game'><img src="https://media.giphy.com/media/l2JecCAExsqUC4HDy/giphy.gif" width={600} height={400} style={{ borderRadius: 100, display: 'block', marginLeft: 'auto', marginRight: 'auto'}} alt="Click button"></img></Link>
			</div>
		);
	}
}
import React from 'react';
import { Button } from 'react-bootstrap';
import Countdown from 'react-countdown-now';

export default class Timer extends React.Component {
	render() {
		return (
			<div style={{margin: 'auto', display: 'block'}} >
				<Button variant="danger" style={{padding: 10}}><Countdown date={Date.now() + 10000} onComplete={this.props.timerEnd}/></Button>
			</div>
		);
	}
}
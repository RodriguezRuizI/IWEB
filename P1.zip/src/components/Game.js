import React from 'react';
import Content from './Content';
import Actionbar from './Actionbar';
import Timer from './Timer';
import { Row } from 'react-bootstrap';

export default class Game extends React.Component {
	render() {
		return (
			<div>
				<Row>
					<Content question={this.props.question} 
						changePrev={this.props.changePrev}
						changeNext={this.props.changeNext}
						changeTo0={this.props.changeTo0}
						changeTo1={this.props.changeTo1}
						changeTo2={this.props.changeTo2}
						changeTo3={this.props.changeTo3}
						changeTo4={this.props.changeTo4}
						changeTo5={this.props.changeTo5}
						changeTo6={this.props.changeTo6}
						changeTo7={this.props.changeTo7}
						changeTo8={this.props.changeTo8}
						changeTo9={this.props.changeTo9}
						currentQuestion={this.props.currentQuestion}
						onQuestionAnswer={this.props.onQuestionAnswer} />
				</Row>

				<Row>
					<Timer timerEnd={this.props.timerEnd}/>  
				</Row>
				<Row>
					<Actionbar currentQuestion={this.props.currentQuestion}
						questions={this.props.questions}
						score={this.props.score}
						changePrev={this.props.changePrev}
						changeNext={this.props.changeNext} 
						reseteo={this.props.reseteo}/>
				</Row>
			</div>
		);
	}
}
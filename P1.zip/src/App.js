import React from 'react';
import './styles/App.css';
import { connect } from 'react-redux';
import Game from './components/Game';
import NavbarComponent from './components/Navbar';
import { questionAnswer,  changeQuestion, submit, initQuestions, timerEnd, changeQuestionTo } from './redux/actions';
import { HashRouter as Router, Route } from 'react-router-dom';
import Homepage from './components/Homepage';
import Authors from './components/Authors';
import { Button, Spinner } from 'react-bootstrap';

class App extends React.Component {

    componentDidMount() {
        fetch('https://quiz.dit.upm.es/api/quizzes/random10wa?token=11a5eb64bda6eabf43f5')
            .then((questions) => {
                return questions.json();
            })
            .then((serverQuestions) => {
                this.props.dispatch(initQuestions(serverQuestions));
            })
            .catch(e => console.error(e))
    }

    render() {
        if (!this.props.finished && !this.props.timeFinished) {
            if (this.props.questions.length !== 0) {
                return (
                    <Router basename="/">
                        <NavbarComponent />
                        <Route path="/" exact component={Homepage} />
                        <Route path="/game" render={(props) => {
                            return (
                                <div>
                                    <Game question={this.props.questions[this.props.currentQuestion]} 
                                        questions={this.props.questions}
                                        changePrev={() => {
                                            this.props.dispatch(changeQuestion(1, this.props.currentQuestion, this.props.questions))}} 
                                        changeNext={() => {
                                            this.props.dispatch(changeQuestion(0, this.props.currentQuestion, this.props.questions))}} 
                                        changeTo0={() => {
                                            this.props.dispatch(changeQuestionTo(0))}} 
                                        changeTo1={() => {
                                            this.props.dispatch(changeQuestionTo(1))}} 
                                        changeTo2={() => {
                                            this.props.dispatch(changeQuestionTo(2))}} 
                                        changeTo3={() => {
                                            this.props.dispatch(changeQuestionTo(3))}} 
                                        changeTo4={() => {
                                            this.props.dispatch(changeQuestionTo(4))}} 
                                        changeTo5={() => {
                                            this.props.dispatch(changeQuestionTo(5))}} 
                                        changeTo6={() => {
                                            this.props.dispatch(changeQuestionTo(6))}} 
                                        changeTo7={() => {
                                            this.props.dispatch(changeQuestionTo(7))}} 
                                        changeTo8={() => {
                                            this.props.dispatch(changeQuestionTo(8))}} 
                                        changeTo9={() => {
                                            this.props.dispatch(changeQuestionTo(9))}} 
                                        score={() => {
                                            this.props.dispatch(submit(this.props.questions))}}
                                        currentQuestion={this.props.currentQuestion}
                                        onQuestionAnswer={(answer) => {
                                            this.props.dispatch(questionAnswer(this.props.currentQuestion, answer))}}
                                        reseteo={() => {window.location.reload(true)}}
                                        timerEnd={() => {this.props.dispatch(timerEnd(this.props.questions))}}
                                    />
                                </div>
                            );
                        } }/>
                        <Route path="/authors" exact component={Authors} />
                    </Router>    
                );
            } else{
                return(<div style={{position: 'absolute', top: '50%', left: '50%', zoom: '200%'}}><Spinner animation="border" role="status"></Spinner><p textAign='center'>Loading...</p></div>);
            }
        } else if (this.props.finished) {
            return (
                <div style={{backgroundColor: '#007BFF', width: '100%'}}>
                    <div style={{backgroundColor: '#007BFF', width: '100%', height: 50}}>
                    </div>
                    <div style={{backgroundColor: 'white', width: '50%', margin: 'auto', display: 'block', padding: 40, borderRadius: 100}}>
                        {this.props.score === 0 ? <h1 align='center' style={{margin: 50}}>We are sorry...</h1> : <h1 align='center' style={{margin: 50}}>Congratulations!</h1> }
                        <h1 align='center' style={{margin: 50}}>Your score is:</h1>
                        <h2 align='center' style={{margin: 50}}>{this.props.score}</h2>
                        <Button style={{margin: 'auto', display: 'block'}} type="button" onClick={() => {window.location.reload(true)}} >Reset</Button>
                    </div>
                    <div style={{backgroundColor: '#007BFF', width: '100%', height: 500}}>
                    </div>
                </div>
            );
        }  else if (this.props.timeFinished) {
            return (
                <div style={{backgroundColor: '#007BFF', width: '100%'}}>
                    <div style={{backgroundColor: '#007BFF', width: '100%', height: 50}}>
                    </div>
                    <div style={{backgroundColor: 'white', width: '50%', margin: 'auto', display: 'block', padding: 40, borderRadius: 100}}>
                        <h1 align='center' style={{margin: 50}}>You have run out of time!</h1>
                        <h1 align='center' style={{margin: 50}}>Your score is:</h1>
                        <h2 align='center' style={{margin: 50}}>{this.props.score}</h2>
                        <Button style={{margin: 'auto', display: 'block'}} type="button" onClick={() => {window.location.reload(true)}} >Reset</Button>
                    </div>
                    <div style={{backgroundColor: '#007BFF', width: '100%', height: 500}}>
                    </div>
                </div>
            );
        }
    }
}

function mapStateToProps(state) {
  return { 
    ...state 
  };
}

export default connect(mapStateToProps)(App);
